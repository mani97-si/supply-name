"use client";
import React from "react";

function MainComponent() {
  const [auth, setAuth] = useState(false);
  const [inventory, setInventory] = useState([
    { id: 1, item: "Tomato", price: 25, stock: 100 },
    { id: 2, item: "Onion", price: 20, stock: 80 },
  ]);
  const [orders, setOrders] = useState([
    { id: 1, item: "Tomato", qty: 10, status: "Pending" },
    { id: 2, item: "Onion", qty: 5, status: "Delivered" },
  ]);

  const toggleStatus = (orderId) => {
    setOrders((prev) =>
      prev.map((order) =>
        order.id === orderId
          ? {
              ...order,
              status: order.status === "Pending" ? "Delivered" : "Pending",
            }
          : order
      )
    );
  };

  const updatePrice = (itemId, newPrice) => {
    setInventory((prev) =>
      prev.map((item) =>
        item.id === itemId
          ? { ...item, price: parseFloat(newPrice) || item.price }
          : item
      )
    );
  };

  if (!auth) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-100">
        <div className="w-80 p-6 bg-white rounded-lg shadow-lg">
          <h2 className="text-xl font-bold mb-4 text-center">Supplier Login</h2>
          <input
            type="email"
            placeholder="Email"
            className="w-full p-3 mb-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <input
            type="password"
            placeholder="Password"
            className="w-full p-3 mb-4 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
          />
          <button
            onClick={() => setAuth(true)}
            className="w-full bg-blue-600 text-white p-3 rounded-md hover:bg-blue-700 transition-colors"
          >
            Login
          </button>
          <p className="text-center text-sm text-gray-600 mt-4">
            Don't have an account?{" "}
            <span className="text-blue-600 cursor-pointer hover:underline">
              Sign up
            </span>
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <h1 className="text-2xl font-bold text-gray-900">
              Supplier Dashboard
            </h1>
            <button
              onClick={() => setAuth(false)}
              className="bg-red-600 text-white px-4 py-2 rounded-md hover:bg-red-700 transition-colors"
            >
              Logout
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <div className="border-b border-gray-200">
            <nav className="-mb-px flex space-x-8">
              <TabButton active={true} onClick={() => {}}>
                <i className="fas fa-boxes mr-2"></i>
                Inventory
              </TabButton>
              <TabButton active={false} onClick={() => {}}>
                <i className="fas fa-shopping-cart mr-2"></i>
                Orders
              </TabButton>
              <TabButton active={false} onClick={() => {}}>
                <i className="fas fa-chart-bar mr-2"></i>
                Analytics
              </TabButton>
            </nav>
          </div>
        </div>

        <TabContent>
          {/* Inventory Tab */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {inventory.map((item) => (
              <InventoryCard
                key={item.id}
                item={item}
                onUpdatePrice={updatePrice}
              />
            ))}
            <AddItemCard />
          </div>

          {/* Orders Tab - Hidden for now */}
          <div className="hidden space-y-4">
            {orders.map((order) => (
              <OrderCard
                key={order.id}
                order={order}
                onToggleStatus={toggleStatus}
              />
            ))}
          </div>

          {/* Analytics Tab - Hidden for now */}
          <div className="hidden">
            <div className="bg-white rounded-lg shadow p-6">
              <h3 className="text-lg font-semibold mb-4">
                Performance Summary
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <p className="text-2xl font-bold text-blue-600">
                    {orders.length}
                  </p>
                  <p className="text-gray-600">Total Orders</p>
                </div>
                <div className="bg-green-50 p-4 rounded-lg">
                  <p className="text-2xl font-bold text-green-600">
                    {orders.filter((o) => o.status === "Delivered").length}
                  </p>
                  <p className="text-gray-600">Delivered</p>
                </div>
                <div className="bg-yellow-50 p-4 rounded-lg">
                  <p className="text-2xl font-bold text-yellow-600">
                    {orders.filter((o) => o.status === "Pending").length}
                  </p>
                  <p className="text-gray-600">Pending</p>
                </div>
              </div>
            </div>
          </div>
        </TabContent>
      </div>
    </div>
  );
}

function TabButton({ active, onClick, children }) {
  return (
    <button
      onClick={onClick}
      className={`py-2 px-1 border-b-2 font-medium text-sm ${
        active
          ? "border-blue-500 text-blue-600"
          : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300"
      }`}
    >
      {children}
    </button>
  );
}

function TabContent({ children }) {
  return <div>{children}</div>;
}

function InventoryCard({ item, onUpdatePrice }) {
  const [newPrice, setNewPrice] = useState("");

  const handleUpdate = () => {
    if (newPrice) {
      onUpdatePrice(item.id, newPrice);
      setNewPrice("");
    }
  };

  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold text-gray-900">{item.item}</h3>
        <div
          className={`px-2 py-1 rounded-full text-xs font-medium ${
            item.stock > 50
              ? "bg-green-100 text-green-800"
              : item.stock > 20
              ? "bg-yellow-100 text-yellow-800"
              : "bg-red-100 text-red-800"
          }`}
        >
          {item.stock > 50
            ? "In Stock"
            : item.stock > 20
            ? "Low Stock"
            : "Critical"}
        </div>
      </div>

      <div className="space-y-2 mb-4">
        <p className="text-gray-600">
          <span className="font-medium">Price:</span> ₹{item.price}/kg
        </p>
        <p className="text-gray-600">
          <span className="font-medium">Stock:</span> {item.stock} kg
        </p>
      </div>

      <div className="flex space-x-2">
        <input
          type="number"
          placeholder="New price"
          value={newPrice}
          onChange={(e) => setNewPrice(e.target.value)}
          className="flex-1 p-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
        />
        <button
          onClick={handleUpdate}
          className="bg-blue-600 text-white px-4 py-2 rounded-md hover:bg-blue-700 transition-colors"
        >
          Update
        </button>
      </div>
    </div>
  );
}

function AddItemCard() {
  return (
    <div className="bg-white rounded-lg shadow p-6 border-2 border-dashed border-gray-300 flex items-center justify-center">
      <button className="text-gray-500 hover:text-gray-700 transition-colors">
        <i className="fas fa-plus text-2xl mb-2"></i>
        <p className="font-medium">Add New Item</p>
      </button>
    </div>
  );
}

function OrderCard({ order, onToggleStatus }) {
  return (
    <div className="bg-white rounded-lg shadow p-6">
      <div className="flex justify-between items-start">
        <div className="flex-1">
          <h3 className="text-lg font-semibold text-gray-900 mb-2">
            Order #{order.id}
          </h3>
          <div className="space-y-1">
            <p className="text-gray-600">
              <span className="font-medium">Item:</span> {order.item}
            </p>
            <p className="text-gray-600">
              <span className="font-medium">Quantity:</span> {order.qty} kg
            </p>
            <p className="text-gray-600">
              <span className="font-medium">Status:</span>
              <span
                className={`ml-2 px-2 py-1 rounded-full text-xs font-medium ${
                  order.status === "Pending"
                    ? "bg-yellow-100 text-yellow-800"
                    : "bg-green-100 text-green-800"
                }`}
              >
                {order.status}
              </span>
            </p>
          </div>
        </div>
        <button
          onClick={() => onToggleStatus(order.id)}
          className={`px-4 py-2 rounded-md font-medium transition-colors ${
            order.status === "Pending"
              ? "bg-green-600 text-white hover:bg-green-700"
              : "bg-yellow-600 text-white hover:bg-yellow-700"
          }`}
        >
          {order.status === "Pending" ? "Mark Delivered" : "Mark Pending"}
        </button>
      </div>
    </div>
  );
}

export default MainComponent;