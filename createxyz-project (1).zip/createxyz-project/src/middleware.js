import { NextResponse } from "next/server";

export const config = {
  matcher: "/integrations/:path*",
};

export function middleware(request) {
  const requestHeaders = new Headers(request.headers);
  requestHeaders.set("x-createxyz-project-id", "d38ed431-2243-470f-9157-cb5ca2328e0e");
  requestHeaders.set("x-createxyz-project-group-id", "50a613a9-bc40-4e75-9f7d-6ec0d6dbe416");


  request.nextUrl.href = `https://www.create.xyz/${request.nextUrl.pathname}`;

  return NextResponse.rewrite(request.nextUrl, {
    request: {
      headers: requestHeaders,
    },
  });
}